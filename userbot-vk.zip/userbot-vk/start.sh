#!/bin/bash
while :
do
    python3.9 main.py
    echo "Waiting before restarting"
    sleep 3
done