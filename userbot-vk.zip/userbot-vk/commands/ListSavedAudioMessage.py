import config
import functions


def cmd(vk, message):
    peer_id = message['peer_id']
    for_all = None if message['from_id'] == message['peer_id'] else True

    audios = functions.getData('saved_audio')

    names = []
    if audios == False or audios == None or audios == '': 
        functions.msg_edit(
            vk, peer_id, message['id'],
            f"{config.prefixes['error']} У вас нет скачанных сообщений ", sleeping=None
        )
    for audio in audios.keys():
        names.append(audio)

    functions.msg_edit(
        vk, peer_id, message['id'],
        f"Ваши скачанные голосовые сообщения: {', '.join(names)}", sleeping=None
    )
    return
