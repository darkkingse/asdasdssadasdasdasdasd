import config
import functions


def cmd(api, message, args, owner_id):
    if message.get('reply_message') is not None:
        target = api.users.get(
            user_ids=message['reply_message']['from_id']
        )
    else:
        try:
            target = api.users.get(
                user_ids=functions.getUserId(args[1])
            )
        except:
            api.messages.edit(
                peer_id=message['peer_id'],
                message_id=message['id'],
                message=f"{config.prefixes['error']} Ответь на сообщение или укажи ID: !чс.r"
            )

    target = target[0]
    try:
        if target['id'] == owner_id:
            api.messages.edit(
                peer_id=message['peer_id'],
                message_id=message['id'],
                message=f"{config.prefixes['error']} Вы не можете разбанить самого себя. "
            )
        else:
            api.messages.edit(
                peer_id=message['peer_id'],
                message_id=message['id'],
                message=f"{config.prefixes['success']} [id{target['id']}|Пользователь] удален из черного списка."
            )
            api.account.unban(owner_id=target['id'])
    except Exception as e:
        print("removeBlackList ", e)
