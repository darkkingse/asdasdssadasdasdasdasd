import psutil

def cmd(api, message, args, owner_id):
    memory = (psutil.virtual_memory())
    disk = (psutil.disk_usage('/'))
    number = 1024 * 1024 * 1024

    memory_total = memory.total / number
    memory_available = memory.available / number
    memory_used = memory.used / number

    disk_total = disk.total / number
    disk_available = disk.free / number
    disk_used = disk.used / number
    try:
        api.messages.edit(
            peer_id=message['peer_id'],
            message_id=message['id'],
            message = f'🖥 Сведения о платформе:\n  📀 ОЗУ:\n      Всего: {memory_total:.3} GB\n      Свободно: {memory_available:.3} GB\n      Используется: {memory_used:.3} GB\n  💿 Нагрузка ЦП: {psutil.cpu_percent()}%\n  💽 Диск:\n      Всего: {disk_total:.4} GB\n      Свободно: {disk_available:.3} GB\n      Используется: {disk_used:.3} GB\n   ',
            disable_mentions=True
        )
    except Exception as e:
        print(e)
        api.messages.edit(
            peer_id=message['peer_id'],
            message_id=message['id'],
            message='Код ошибки: 4',
            disable_mentions=True
        )