import time
import config
import functions


def cmd(api, message, args, owner_id):
    for_all = None if message['from_id'] == message['peer_id'] else True

    if message.get('reply_message') is not None:
        target = api.users.get(
            user_ids=message['reply_message']['from_id']
        )
    else:
        try:
            target = api.users.get(
                user_ids=functions.getUserId(args[1])
            )
        except:
            api.messages.edit(
                peer_id=message['peer_id'],
                message_id=message['id'],
                message=f"{config.prefixes['error']} Ответь на сообщение пользователя или укажи на него ID: !ignore.a [ID]"
            )
            print("no")

    ignored_users = functions.getData('ignore')
    if ignored_users is None:
        ignored_users = []

    target = target[0]
    if target['id'] in ignored_users:
        api.messages.edit(
            peer_id=message['peer_id'],
            message_id=message['id'],
            message=f"{config.prefixes['invalid']} [id{target['id']}|{target['first_name']} {target['last_name']}] уже в игнор-списке."
        )
        return

    if owner_id == target['id']:
        api.messages.edit(
            peer_id=message['peer_id'],
            message_id=message['id'],
            message="ты даун?"
        )
        return

    ignored_users.append(target['id'])
    edit = functions.editData('ignore', ignored_users)

    if edit:
        api.messages.edit(
            peer_id=message['peer_id'],
            message_id=message['id'],
            message=f"{config.prefixes['success']} [id{target['id']}|{target['first_name']} {target['last_name']}] занесён в игнор-лист"
        )

    return
