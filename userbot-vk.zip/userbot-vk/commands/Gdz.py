from logging import exception
from bs4 import BeautifulSoup
import requests
import os
import functions
import config
from vk_api import VkUpload


def html(req):
    r = requests.get(req)
    return r.text


def get_html(site):
    lol = []
    soup = BeautifulSoup(site, "lxml")
    global lenImg
    try:
        ranges = over = soup.find_all(
            'div', class_='with-overtask')
        for s in ranges:
            imgGdz = s.find_all('img')
            lol.append(imgGdz)
        for lenImg in range(0, len(lol)):
            over = soup.find_all(
                'div', class_='with-overtask')[lenImg].find('img')
            r = over['src']
            p = requests.get(r)
            with open(f'files/{lenImg}.png', 'wb') as f:
                f.write(p.content)
    except Exception as e:
        print(e)


def cmd(api, vk, message, args, uploader: VkUpload):
    dictionary = {'алгебра': f'https://megaresheba.ru/index/reshebnik_po_algebre_8_klass_makarychev_2012/0-4637/{args[2]}-nomer',
                  'русский': f'https://megaresheba.ru/publ/reshebnik/russkomu_jazyku/8_klass_trostencova/35-1-0-1218/{args[2]}-nomer',
                  'английский': f'https://megaresheba.ru/index/sru8_eng4/0-4588/{args[2]}-str'}
    try:
        peer_id = message['peer_id']
        get_html(html(dictionary[args[1]]))
        for lenImgs in range(0, lenImg+1):
            filename = f'files/{lenImgs}.png'
            uploaded = uploader.photo_messages(
                filename, peer_id=message['peer_id'])[0]
            attach = f"photo{uploaded['owner_id']}_{uploaded['id']}"
            functions.msg_send(
                vk,
                peer_id,
                attachment=attach,
                reply_to=message['id']
            )
            os.remove(filename)

    except Exception as e:
        print(e)
