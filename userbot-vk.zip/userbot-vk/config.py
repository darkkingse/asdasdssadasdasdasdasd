access_token = "vk1.a.wUJS-ASIatpbXEBd023FUhBfvnSG8ecQnw32vxl25GoRVpzj3S7yLGImB1ds4rJhnPON0xAcbw9cA-huLMsoxWzyH6CN-OhDRCz0ilVBoG_MZ4GzeRjqLzjHEPMJEdL63e3z8j6JJOKZJHE3n6xFvqv8n1NolKGeCF-d6xRhVE8TsCb65-nlTQ4dxa2m_vnH"  # токен пользователя (vk.cc/a6dCgm)
log_messages = True  # логировать ли сообщения

prefixes = {  # префиксы, перед сообщениями
    "error": "❗",  # Ошибка при использовании
    "invalid": "⚠️",  # Какой-то недочет в запросе
    "process": "⚡ ",  # Испоьзуется когда процесс может выполняться долгое время
    "success": "✅ ",  # Используется когда все прошло успешно
    "success_no": "❎"  # Используется когда все прошло успешно, но ответ отрицательный
}

odeanon_token = False
